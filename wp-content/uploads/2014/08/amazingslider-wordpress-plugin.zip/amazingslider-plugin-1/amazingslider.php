<?php
/*
Plugin Name: Amazing Slider 1
Plugin URI: http://amazingslider.com
Description: Amazing Slider WordPress Plugin 1
Version: 1.8
Author: Magic Hills Pty Ltd
Author URI: http://amazingslider.com
License: Copyright 2013 Magic Hills Pty Ltd, All Rights Reserved
*/

define('AMAZINGSLIDER_VERSION_1', '1.8');

define('AMAZINGSLIDER_URL_1', plugin_dir_url( __FILE__ ));

define('AMAZINGSLIDER_PATH_1', plugin_dir_path( __FILE__ ));

class AmazingSlider_Plugin_1
{
		
	function __construct() {
		
		$this->init();
	}
	
	public function init()
	{
				
		add_action( 'admin_menu', array($this, 'register_menu') );
		
		add_shortcode( 'amazingslider1', array($this, 'shortcode_handler') );
		
		add_action( 'init', array($this, 'register_script') );
	}
		
	function register_script()
	{
		$script_url = AMAZINGSLIDER_URL_1 . '/data/sliderengine/amazingslider.js';
		wp_register_script('amazingslider-script-1', $script_url, array('jquery'), AMAZINGSLIDER_VERSION_1, false);
		wp_enqueue_script('amazingslider-script-1');
		
		$initscript_url = AMAZINGSLIDER_URL_1 . '/data/sliderengine/initslider-1.js';
		wp_register_script('amazingslider-initscript-1', $initscript_url, array('jquery'), AMAZINGSLIDER_VERSION_1, false);
		wp_enqueue_script('amazingslider-initscript-1');
		
		$style_url = AMAZINGSLIDER_URL_1 . 'data/sliderengine/initslider-1.css';
		wp_register_style('amazingslider-style-1', $style_url);
		wp_enqueue_style('amazingslider-style-1');
		
		if ( is_admin() )
		{
			wp_register_style('amazingslider-admin-style-1', AMAZINGSLIDER_URL_1 . 'amazingslider.css');
			wp_enqueue_style('amazingslider-admin-style-1');
		}
	}
	
	function shortcode_handler($atts)
	{
		return $this->generate_codes();
	}
	
	function generate_codes()
	{
		$file = AMAZINGSLIDER_PATH_1 . '/data/slider.html';
		$content = file_get_contents($file);
		
		$dest_url = AMAZINGSLIDER_URL_1 . '/data/';
		
		$slidercode = "";
		$pattern = '/<!-- Insert to your webpage where you want to display the slider -->(.*)<!-- End of body section HTML codes -->/s';
		if ( preg_match($pattern, $content, $matches) )
			$slidercode = str_replace("%DESTURL%", $dest_url, $matches[1]);
		
		return $slidercode;
	}
	
	function register_menu()
	{
		add_menu_page( 
				__('Amazing Slider 1', 'amazingslider1'), 
				__('Amazing Slider 1', 'amazingslider1'), 
				'manage_options', 
				'amazingslider1_show_slider', 
				array($this, 'show_slider'),
				AMAZINGSLIDER_URL_1 . 'images/logo-16.png' );
				
	}
	
	public function show_slider()
	{
		
		?>
		<div class="wrap">
		<div id="icon-amazingslider" class="icon32"><br /></div>
			
		<h2><?php _e( 'View Slider', 'amazingslider1' ); ?></h2>
				
		<div class="updated"><p style="text-align:center;"> To embed the slider into your page, use shortcode <strong><?php echo esc_attr('[amazingslider1]'); ?></strong></p></div>
		
		<div class="updated"><p style="text-align:center;"> To embed the slider into your template, use php code <strong><?php echo esc_attr('<?php echo do_shortcode(\'[amazingslider1]\'); ?>'); ?></strong></p></div>
				
		<?php
			echo $this->generate_codes();
		?>	 
		
		</div>
		
		<?php
	}
	
}

$amazingslider_plugin_1 = new AmazingSlider_Plugin_1();
